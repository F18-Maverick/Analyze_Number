#### gui文档
- 初衷：
    - 一开始是不打算做gui页面，但是看到群里这么多小伙伴配置不了文件，心里着急的很，连夜赶工了一个初级版本，大家轻喷。。。。
    - 不过如果你喜欢小黑框框，没问题，一样的支持
- 使用帮助
     - [server酱配置姿势](https://www.jianshu.com/p/8d10b5b9c4e3)
     - windows支持64位使用
     - macos打开姿势（请不要直接打卡app，有可能会造成闪退，如果有同学知道是什么问题，烦请提issues）
     - ![image](https://github.com/testerSunshine/12306/blob/master/uml/mac1.png)
     - ![image](https://github.com/testerSunshine/12306/blob/master/uml/mac2.png)
- ps:
    - 默认开始设置
        - 默认开启自动打码，第一次登陆手动
        - 默认设置下单接口2
        - 默认开启cdn
- 说了这么多，给我们的小软件起个名字吧，叫易行吧。
    - gui期待小伙伴的pr
- 版权声明
    - 本着开源的目的，服务大家，中间没有任何的收集包括联系人信息，电脑信息，算了算了，反正就是都没有
    - 请勿将本软件售卖和进行非法经营(违背12306官方意愿)
    - 最终解释权为本人所有
    - 软件终身免费，永不收费
- 后续计划
    - 剥离所有yaml配置文件（工作太忙了，尽量在本周之前完成）(已完成)
    - cmd命令输出改到gui里面，不然很多小伙伴乱码，我也是很头大(已完成)
    - 打包成独立运行文件(已完成)
    - 自动识别验证码（所有群里小伙伴的意愿吧~~）(未完成)
    - ....
- 感谢群里和github上一直默默支持我和使用我软件的同学，真的非常感谢

- 软件界面截图：
    ![image](https://github.com/testerSunshine/12306/blob/master/uml/登录.png)
    ![image](https://github.com/testerSunshine/12306/blob/master/uml/程序主界面.png)
