class ticketNumOutException(Exception):
    pass